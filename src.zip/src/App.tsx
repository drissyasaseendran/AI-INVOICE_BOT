import React, { useState, useCallback } from 'react';
import InvoiceUploader from './components/InvoiceUploader';
import InvoiceTable from './components/InvoiceTable';
import InvoiceDetailModal from './components/InvoiceDetailModal';
import ChatPanel from './components/ChatPanel';
import AnalyticsDashboard from './components/AnalyticsDashboard';
import { Invoice, InvoiceExtracted, Analytics } from './types';
import { uploadInvoices, updateInvoice, getAnalytics, generateSamples, clearInvoices } from './api';
import './App.css';

type Tab = 'invoices' | 'analytics';

export default function App() {
  const [invoices, setInvoices]   = useState<Invoice[]>([]);
  const [analytics, setAnalytics] = useState<Analytics | null>(null);
  const [loading, setLoading]     = useState(false);
  const [selected, setSelected]   = useState<Invoice | null>(null);
  const [error, setError]         = useState('');
  const [tab, setTab]             = useState<Tab>('invoices');
  const [genLoading, setGenLoading] = useState(false);

  const refreshAnalytics = useCallback(async () => {
    try {
      const { data } = await getAnalytics();
      setAnalytics(data);
    } catch { /* silent */ }
  }, []);

  const handleUpload = async (files: File[]) => {
    setError('');
    setLoading(true);
    try {
      const { data } = await uploadInvoices(files);
      setInvoices(prev => [...prev, ...data]);
      await refreshAnalytics();
    } catch (e: any) {
      setError(e?.response?.data?.detail || e.message || 'Upload failed');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async (id: string, patch: Partial<InvoiceExtracted>) => {
    try {
      const { data } = await updateInvoice(id, patch);
      setInvoices(prev => prev.map(inv => inv.id === id ? data : inv));
      await refreshAnalytics();
    } catch (e: any) {
      setError(e?.response?.data?.detail || e.message || 'Save failed');
    }
  };

  const handleClearAll = async () => {
    if (!window.confirm('Clear all invoices? This cannot be undone.')) return;
    try {
      await clearInvoices();
      setInvoices([]);
      setAnalytics(null);
      setSelected(null);
      setError('');
    } catch (e: any) {
      setError(e?.response?.data?.detail || e.message || 'Clear failed');
    }
  };

  const handleGenerateSamples = async () => {
    setGenLoading(true);
    setError('');
    try {
      const { data } = await generateSamples();
      setInvoices(data);
      await refreshAnalytics();
    } catch (e: any) {
      setError(e?.response?.data?.detail || e.message || 'Generation failed');
    } finally {
      setGenLoading(false);
    }
  };

  const extractedCount = invoices.length;

  const stats = {
    total:    invoices.length,
    erp:      invoices.filter(i => i.erp_ready).length,
    issues:   invoices.filter(i => i.validation_issues.length > 0).length,
    reviewed: invoices.filter(i => i.status === 'reviewed').length,
  };

  return (
    <div className="app">
      <header className="app-header">
        <div className="header-left">
          <span className="header-logo">🧾</span>
          <div>
            <div className="header-title">BILL BOT - Invoice Intelligence</div>
            <div className="header-sub">AI-Powered Back-Office Finance Automation · TCS GenAI Lab</div>
          </div>
        </div>
        <div className="header-right">
          {invoices.length > 0 && (
            <div className="stats-bar">
              <span className="stat"><strong>{stats.total}</strong> Invoices</span>
              <span className="stat ok"><strong>{stats.erp}</strong> ERP Ready</span>
              <span className="stat warn"><strong>{stats.issues}</strong> Issues</span>
              <span className="stat blue"><strong>{stats.reviewed}</strong> Reviewed</span>
            </div>
          )}
          <button
            className="btn-demo"
            onClick={handleGenerateSamples}
            disabled={genLoading}
          >
            {genLoading ? '⏳ Generating…' : '🎲 Load 20 Sample Invoices'}
          </button>
          {invoices.length > 0 && (
            <button className="btn-clear" onClick={handleClearAll}>🗑 Clear All</button>
          )}
        </div>
      </header>

      <div className="workspace">
        {/* Left panel */}
        <main className="invoice-panel">
          <div className="tab-bar">
            <button className={`tab ${tab === 'invoices' ? 'tab-active' : ''}`} onClick={() => setTab('invoices')}>
              📋 Invoices {invoices.length > 0 && <span className="tab-count">{invoices.length}</span>}
            </button>
            <button className={`tab ${tab === 'analytics' ? 'tab-active' : ''}`} onClick={() => { setTab('analytics'); refreshAnalytics(); }}>
              📊 Analytics
            </button>
          </div>

          {error && (
            <div className="error-bar">⚠️ {error}<button onClick={() => setError('')}>✕</button></div>
          )}

          {tab === 'invoices' && (
            <>
              <InvoiceUploader onUpload={handleUpload} loading={loading} />
              <InvoiceTable invoices={invoices} onSelect={setSelected} />
            </>
          )}

          {tab === 'analytics' && analytics && (
            <AnalyticsDashboard data={analytics} />
          )}

          {tab === 'analytics' && !analytics && (
            <div className="empty-analytics">Upload invoices to see analytics.</div>
          )}
        </main>

        {/* Right: chat */}
        <aside className="chat-aside">
          <ChatPanel invoiceCount={extractedCount} />
        </aside>
      </div>

      {selected && (
        <InvoiceDetailModal
          invoice={selected}
          onClose={() => setSelected(null)}
          onSave={handleSave}
        />
      )}
    </div>
  );
}
