export interface LineItem {
  description: string;
  quantity: string;
  unit_price: string;
  total: string;
}

export interface InvoiceExtracted {
  vendor_name: string | null;
  vendor_address: string | null;
  vendor_email: string | null;
  invoice_number: string | null;
  po_number: string | null;
  invoice_date: string | null;
  due_date: string | null;
  payment_terms: string | null;
  currency: string | null;
  subtotal: string | null;
  tax: string | null;
  tax_rate: string | null;
  discount: string | null;
  amount: string | null;
  line_items: LineItem[];
}

export interface Invoice {
  id: string;
  filename: string;
  status: 'processing' | 'done' | 'error' | 'reviewed';
  extracted: InvoiceExtracted;
  validation_issues: string[];
  erp_ready: boolean;
  error: string | null;
  uploaded_at: string;
}

export interface ChatMessage {
  role: 'user' | 'assistant';
  type: 'text' | 'table';
  content?: string;
  columns?: string[];
  rows?: string[][];
}

export interface Analytics {
  total: number;
  extracted: number;
  reviewed: number;
  erp_ready: number;
  with_issues: number;
  errors: number;
  total_spend: number;
  by_vendor: { vendor: string; amount: number }[];
  by_status: { status: string; count: number }[];
  issue_types: { type: string; count: number }[];
}
