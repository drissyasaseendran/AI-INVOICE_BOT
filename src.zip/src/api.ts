import axios from 'axios';
import { Invoice, Analytics } from './types';

const api = axios.create({ baseURL: 'http://localhost:8000' });

export const uploadInvoices = (files: File[]) => {
  const form = new FormData();
  files.forEach(f => form.append('files', f));
  return api.post<Invoice[]>('/invoice/upload', form);
};

export const updateInvoice = (id: string, patch: Partial<Invoice['extracted']>) =>
  api.patch<Invoice>(`/invoice/${id}`, patch);

export const listInvoices = () => api.get<Invoice[]>('/invoices');

export const getAnalytics = () => api.get<Analytics>('/analytics');

export const generateSamples = () => api.post<Invoice[]>('/invoice/generate-samples');

export const clearInvoices = () => api.delete('/invoices');

export const chatWithInvoices = (message: string, history: { role: string; content: string }[]) =>
  api.post<{ type: 'table' | 'text'; content?: string; columns?: string[]; rows?: string[][] }>('/chat', { message, history });
