import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage } from '../types';
import { chatWithInvoices } from '../api';

interface Props { invoiceCount: number; }

const SUGGESTIONS = [
  'Show all invoices',
  'List invoices with validation issues',
  'Show all ERP-ready invoices',
  'Show invoices with amount mismatch',
  'List all invoices missing a PO number',
  'What is the total spend across all invoices?',
  'Which invoices are overdue?',
  'What are the top vendors by amount?',
];

const WELCOME: ChatMessage = {
  role: 'assistant',
  type: 'text',
  content:
    '👋 Hello! I\'m your Invoice Intelligence assistant.\n\n' +
    'Once invoices are uploaded or sample data is loaded, I can:\n' +
    '• Show full invoice lists as a table\n' +
    '• Look up any invoice by number or vendor\n' +
    '• Filter by issues, ERP readiness, or status\n' +
    '• Summarise totals and flag discrepancies\n\n' +
    'Try one of the suggested queries below ↓',
};

function ChatBubble({ msg }: { msg: ChatMessage }) {
  if (msg.role === 'user') {
    return (
      <div className="chat-msg chat-msg-user">
        <div className="chat-avatar">👤</div>
        <div className="chat-bubble">
          <pre className="chat-text">{msg.content}</pre>
        </div>
      </div>
    );
  }

  // Assistant — table response
  if (msg.type === 'table' && msg.columns && msg.rows) {
    return (
      <div className="chat-msg chat-msg-assistant">
        <div className="chat-avatar">🤖</div>
        <div className="chat-table-wrap">
          <div className="chat-table-count">{msg.rows.length} record{msg.rows.length !== 1 ? 's' : ''}</div>
          <div className="chat-table-scroll">
            <table className="chat-table">
              <thead>
                <tr>{msg.columns.map((col, i) => <th key={i}>{col}</th>)}</tr>
              </thead>
              <tbody>
                {msg.rows.map((row, ri) => (
                  <tr key={ri}>
                    {row.map((cell, ci) => (
                      <td key={ci}>
                        {/* Colour-code ERP Ready and Status cells */}
                        {msg.columns![ci] === 'ERP Ready'
                          ? <span className={cell === 'true' || cell === 'Yes' ? 'erp-dot erp-dot-yes' : 'erp-dot erp-dot-no'} title={cell} />
                          : msg.columns![ci] === 'Status'
                          ? <span className={`badge badge-${String(cell).toLowerCase()}`}>{cell}</span>
                          : msg.columns![ci] === 'Issues' && cell !== 'None' && cell !== '' && cell !== '0'
                          ? <span className="issues-count">⚠️ {cell}</span>
                          : cell || '—'}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  }

  // Assistant — text response
  return (
    <div className="chat-msg chat-msg-assistant">
      <div className="chat-avatar">🤖</div>
      <div className="chat-bubble">
        <pre className="chat-text">{msg.content}</pre>
      </div>
    </div>
  );
}

export default function ChatPanel({ invoiceCount }: Props) {
  const [messages, setMessages] = useState<ChatMessage[]>([WELCOME]);
  const [input, setInput]       = useState('');
  const [loading, setLoading]   = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const send = async (text: string) => {
    text = text.trim();
    if (!text || loading) return;
    setInput('');

    const userMsg: ChatMessage = { role: 'user', type: 'text', content: text };
    const history = messages
      .filter(m => m !== WELCOME)
      .map(m => ({ role: m.role, content: m.content || (m.type === 'table' ? '[table response]' : '') }));

    setMessages(prev => [...prev, userMsg]);
    setLoading(true);

    try {
      const { data } = await chatWithInvoices(text, history);
      const assistantMsg: ChatMessage = {
        role: 'assistant',
        type: data.type,
        content: data.content,
        columns: data.columns,
        rows: data.rows,
      };
      setMessages(prev => [...prev, assistantMsg]);
    } catch (e: any) {
      setMessages(prev => [...prev, {
        role: 'assistant',
        type: 'text',
        content: `⚠️ ${e?.response?.data?.detail || e.message || 'Something went wrong'}`,
      }]);
    } finally {
      setLoading(false);
    }
  };

  const onKey = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(input); }
  };

  return (
    <div className="chat-panel">
      <div className="chat-panel-header">
        <span>💬 Invoice Assistant</span>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span className="chat-invoice-count">{invoiceCount} invoice{invoiceCount !== 1 ? 's' : ''}</span>
          <button className="chat-clear-btn" onClick={() => setMessages([WELCOME])} title="Clear chat">🗑</button>
        </div>
      </div>

      <div className="chat-messages">
        {messages.map((msg, i) => <ChatBubble key={i} msg={msg} />)}
        {loading && (
          <div className="chat-msg chat-msg-assistant">
            <div className="chat-avatar">🤖</div>
            <div className="chat-bubble typing">
              <span className="dot" /><span className="dot" /><span className="dot" />
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {messages.length === 1 && (
        <div className="suggestions-wrap">
          {SUGGESTIONS.map(s => (
            <button key={s} className="suggestion-chip" onClick={() => send(s)}>{s}</button>
          ))}
        </div>
      )}

      <div className="chat-input-row">
        <textarea
          className="chat-input"
          rows={1}
          placeholder={invoiceCount === 0 ? 'Load invoices or generate samples first…' : 'Ask about your invoices…'}
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={onKey}
          disabled={loading}
        />
        <button
          className="chat-send-btn"
          onClick={() => send(input)}
          disabled={loading || !input.trim()}
        >
          {loading ? <span className="spinner-sm" /> : '➤'}
        </button>
      </div>
    </div>
  );
}
