import React from 'react';
import { Analytics } from '../types';

interface Props { data: Analytics; }

export default function AnalyticsDashboard({ data }: Props) {
  if (data.total === 0) return null;

  const erpPct   = data.total > 0 ? Math.round((data.erp_ready / data.total) * 100) : 0;
  const issuePct = data.total > 0 ? Math.round((data.with_issues / data.total) * 100) : 0;

  const maxVendor = data.by_vendor[0]?.amount || 1;

  return (
    <div className="analytics">
      {/* KPI Cards */}
      <div className="kpi-row">
        <div className="kpi-card">
          <div className="kpi-value">{data.total}</div>
          <div className="kpi-label">Total Invoices</div>
        </div>
        <div className="kpi-card kpi-green">
          <div className="kpi-value">{data.erp_ready}</div>
          <div className="kpi-label">ERP Ready</div>
          <div className="kpi-sub">{erpPct}% of total</div>
        </div>
        <div className="kpi-card kpi-orange">
          <div className="kpi-value">{data.with_issues}</div>
          <div className="kpi-label">Need Review</div>
          <div className="kpi-sub">{issuePct}% of total</div>
        </div>
        <div className="kpi-card kpi-blue">
          <div className="kpi-value">${data.total_spend.toLocaleString()}</div>
          <div className="kpi-label">Total Spend</div>
        </div>
        <div className="kpi-card kpi-purple">
          <div className="kpi-value">{data.reviewed}</div>
          <div className="kpi-label">Reviewed</div>
        </div>
      </div>

      <div className="analytics-row">
        {/* Top Vendors */}
        {data.by_vendor.length > 0 && (
          <div className="analytics-card">
            <div className="analytics-card-title">💰 Top Vendors by Spend</div>
            {data.by_vendor.slice(0, 6).map(v => (
              <div key={v.vendor} className="bar-row">
                <div className="bar-label" title={v.vendor}>{v.vendor}</div>
                <div className="bar-track">
                  <div className="bar-fill" style={{ width: `${(v.amount / maxVendor) * 100}%` }} />
                </div>
                <div className="bar-value">${v.amount.toLocaleString()}</div>
              </div>
            ))}
          </div>
        )}

        {/* Issue Types */}
        {data.issue_types.length > 0 && (
          <div className="analytics-card">
            <div className="analytics-card-title">⚠️ Validation Issue Breakdown</div>
            {data.issue_types.map(it => (
              <div key={it.type} className="issue-row">
                <span className="issue-type">{it.type}</span>
                <span className="issue-badge">{it.count}</span>
              </div>
            ))}
          </div>
        )}

        {/* Status donut-style */}
        <div className="analytics-card">
          <div className="analytics-card-title">📊 Processing Status</div>
          {data.by_status.filter(s => s.count > 0).map(s => (
            <div key={s.status} className="status-row">
              <span className="status-label">{s.status}</span>
              <div className="status-bar-track">
                <div
                  className={`status-bar-fill status-fill-${s.status.toLowerCase()}`}
                  style={{ width: `${(s.count / data.total) * 100}%` }}
                />
              </div>
              <span className="status-count">{s.count}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
