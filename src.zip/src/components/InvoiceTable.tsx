import React, { useState } from 'react';
import { Invoice } from '../types';

interface Props {
  invoices: Invoice[];
  onSelect: (inv: Invoice) => void;
}

const STATUS_LABEL: Record<string, string> = {
  processing: '⏳ Processing',
  done:       '✅ Extracted',
  reviewed:   '✔️ Reviewed',
  error:      '❌ Error',
};

type Filter = 'all' | 'issues' | 'erp_ready' | 'reviewed';

export default function InvoiceTable({ invoices, onSelect }: Props) {
  const [filter, setFilter] = useState<Filter>('all');
  const [search, setSearch] = useState('');

  if (invoices.length === 0) return null;

  const filtered = invoices.filter(inv => {
    const matchFilter =
      filter === 'all'       ? true :
      filter === 'issues'    ? inv.validation_issues.length > 0 :
      filter === 'erp_ready' ? inv.erp_ready :
      filter === 'reviewed'  ? inv.status === 'reviewed' : true;

    const q = search.toLowerCase();
    const matchSearch = !q || (
      inv.filename.toLowerCase().includes(q) ||
      (inv.extracted?.vendor_name ?? '').toLowerCase().includes(q) ||
      (inv.extracted?.invoice_number ?? '').toLowerCase().includes(q)
    );
    return matchFilter && matchSearch;
  });

  const counts = {
    all:       invoices.length,
    issues:    invoices.filter(i => i.validation_issues.length > 0).length,
    erp_ready: invoices.filter(i => i.erp_ready).length,
    reviewed:  invoices.filter(i => i.status === 'reviewed').length,
  };

  return (
    <div className="table-section">
      <div className="table-toolbar">
        <div className="filter-tabs">
          {(['all', 'issues', 'erp_ready', 'reviewed'] as Filter[]).map(f => (
            <button
              key={f}
              className={`filter-tab ${filter === f ? 'active' : ''}`}
              onClick={() => setFilter(f)}
            >
              {f === 'all' ? 'All' : f === 'issues' ? '⚠️ Issues' : f === 'erp_ready' ? '✅ ERP Ready' : '✔️ Reviewed'}
              <span className="tab-count">{counts[f]}</span>
            </button>
          ))}
        </div>
        <input
          className="table-search"
          placeholder="Search vendor, invoice #…"
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
      </div>

      <div className="table-wrap">
        <table className="invoice-table">
          <thead>
            <tr>
              <th>#</th>
              <th>Invoice ID</th>
              <th>Vendor Name</th>
              <th>Invoice #</th>
              <th>Date</th>
              <th>Due Date</th>
              <th>Amount</th>
              <th>ERP</th>
              <th>Status</th>
              <th>Issues</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((inv, idx) => (
              <tr key={inv.id} className={inv.validation_issues.length > 0 ? 'row-warn' : ''}>
                <td className="td-num">{idx + 1}</td>
                <td>
                  <div className="td-id" title={inv.id}>{inv.id.slice(0, 8).toUpperCase()}</div>
                  <div className="td-filename" title={inv.filename}>{inv.filename}</div>
                </td>
                <td className="td-vendor">{inv.extracted?.vendor_name ?? <span className="td-missing">Not extracted</span>}</td>
                <td className="td-mono">{inv.extracted?.invoice_number ?? <span className="td-missing">—</span>}</td>
                <td>{inv.extracted?.invoice_date ?? '—'}</td>
                <td>{inv.extracted?.due_date ?? '—'}</td>
                <td className="td-amount">
                  {inv.extracted?.amount
                    ? `${inv.extracted.currency ?? ''} ${parseFloat(inv.extracted.amount).toLocaleString(undefined, {minimumFractionDigits: 2})}`
                    : '—'}
                </td>
                <td>
                  <span className={`erp-dot ${inv.erp_ready ? 'erp-dot-yes' : 'erp-dot-no'}`}
                        title={inv.erp_ready ? 'ERP Ready' : 'Not ERP Ready'} />
                </td>
                <td>
                  <span className={`badge badge-${inv.status}`}>{STATUS_LABEL[inv.status]}</span>
                </td>
                <td>
                  {inv.validation_issues.length > 0
                    ? <span className="issues-count" title={inv.validation_issues.join('\n')}>⚠️ {inv.validation_issues.length}</span>
                    : <span className="no-issues">✓</span>}
                </td>
                <td>
                  {inv.status !== 'processing' && (
                    <button className="btn-review" onClick={() => onSelect(inv)}>Review</button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length === 0 && (
          <div className="table-empty">No invoices match the current filter.</div>
        )}
      </div>
    </div>
  );
}
