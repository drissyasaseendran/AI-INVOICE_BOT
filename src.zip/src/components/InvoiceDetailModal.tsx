import React, { useState, useEffect } from 'react';
import { Invoice, InvoiceExtracted } from '../types';

interface Props {
  invoice: Invoice;
  onClose: () => void;
  onSave: (id: string, patch: Partial<InvoiceExtracted>) => void;
}

// ── PII masking helpers ────────────────────────────────────────────────────

const maskEmail = (val: string) => {
  const [user, domain] = val.split('@');
  if (!domain) return '••••••@••••••';
  return `${user[0]}${'•'.repeat(Math.max(user.length - 1, 3))}@${domain}`;
};

const maskAddress = (val: string) => {
  // Keep city/state, mask street number and name
  const parts = val.split(',');
  if (parts.length <= 1) return '•'.repeat(Math.min(val.length, 12)) + val.slice(-6);
  return `${'••••••••••'}, ${parts.slice(1).join(',').trim()}`;
};

const maskName = (val: string) => {
  const words = val.trim().split(' ');
  return words.map((w, i) =>
    i === 0 ? w[0] + '•'.repeat(Math.max(w.length - 1, 2)) : w
  ).join(' ');
};

const PII_FIELDS = new Set<keyof InvoiceExtracted>([
  'vendor_email', 'vendor_address', 'vendor_name',
]);

function applyMask(key: keyof InvoiceExtracted, val: string): string {
  if (!val) return val;
  if (key === 'vendor_email')   return maskEmail(val);
  if (key === 'vendor_address') return maskAddress(val);
  if (key === 'vendor_name')    return maskName(val);
  return val;
}

// ── Field config ───────────────────────────────────────────────────────────

const FIELDS: { key: keyof InvoiceExtracted; label: string; span?: boolean; pii?: boolean }[] = [
  { key: 'vendor_name',    label: 'Vendor Name',    span: true,  pii: true  },
  { key: 'vendor_address', label: 'Vendor Address', span: true,  pii: true  },
  { key: 'vendor_email',   label: 'Vendor Email',                pii: true  },
  { key: 'invoice_number', label: 'Invoice #' },
  { key: 'po_number',      label: 'PO Number' },
  { key: 'invoice_date',   label: 'Invoice Date' },
  { key: 'due_date',       label: 'Due Date' },
  { key: 'payment_terms',  label: 'Payment Terms' },
  { key: 'currency',       label: 'Currency' },
  { key: 'subtotal',       label: 'Subtotal' },
  { key: 'tax_rate',       label: 'Tax Rate' },
  { key: 'tax',            label: 'Tax Amount' },
  { key: 'discount',       label: 'Discount' },
  { key: 'amount',         label: 'Total Amount' },
];

// ── Component ──────────────────────────────────────────────────────────────

export default function InvoiceDetailModal({ invoice, onClose, onSave }: Props) {
  const [form, setForm]       = useState<Partial<InvoiceExtracted>>({});
  const [revealed, setRevealed] = useState(false);

  useEffect(() => { setForm({ ...invoice.extracted }); setRevealed(false); }, [invoice]);

  const change = (key: keyof InvoiceExtracted, val: string) =>
    setForm(f => ({ ...f, [key]: val }));

  const save = () => { onSave(invoice.id, form); onClose(); };

  const displayValue = (key: keyof InvoiceExtracted): string => {
    const raw = (form[key] as string) ?? '';
    if (!raw) return '';
    return (!revealed && PII_FIELDS.has(key)) ? applyMask(key, raw) : raw;
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>

        <div className="modal-header">
          <div>
            <h2>📄 {invoice.filename}</h2>
            <div className="modal-meta">
              <span className={`badge badge-${invoice.status}`}>{invoice.status}</span>
              <span className={`erp-badge ${invoice.erp_ready ? 'erp-yes' : 'erp-no'}`}>
                {invoice.erp_ready ? '✅ ERP Ready' : '⛔ Not ERP Ready'}
              </span>
              <button
                className={`pii-toggle ${revealed ? 'pii-revealed' : ''}`}
                onClick={() => setRevealed(r => !r)}
                title={revealed ? 'Mask PII data' : 'Reveal PII data'}
              >
                {revealed ? '🔒 Mask PII' : '👁 Reveal PII'}
              </button>
            </div>
          </div>
          <button className="modal-close" onClick={onClose}>✕</button>
        </div>

        {!revealed && (
          <div className="pii-notice">
            🔐 PII fields (vendor name, address, email) are masked. Click <strong>👁 Reveal PII</strong> to view or edit.
          </div>
        )}

        {invoice.validation_issues.length > 0 && (
          <div className="validation-box">
            <strong>⚠️ Validation Issues — correct fields below to mark ERP ready</strong>
            <ul>{invoice.validation_issues.map((v, i) => <li key={i}>{v}</li>)}</ul>
          </div>
        )}

        <div className="modal-fields">
          {FIELDS.map(({ key, label, span, pii }) => (
            <div className={`field-row ${span ? 'field-span' : ''}`} key={key}>
              <label>
                {label}
                {pii && <span className="pii-tag">PII</span>}
              </label>
              <input
                value={displayValue(key)}
                onChange={e => {
                  if (!revealed && pii) return; // block editing masked fields
                  change(key, e.target.value);
                }}
                placeholder={(!revealed && pii) ? '••••••••••' : `Enter ${label}`}
                className={!revealed && pii ? 'input-masked' : ''}
                readOnly={!revealed && !!pii}
                title={!revealed && pii ? 'Reveal PII to edit this field' : undefined}
              />
            </div>
          ))}
        </div>

        {(invoice.extracted.line_items?.length ?? 0) > 0 && (
          <div className="line-items">
            <strong>Line Items</strong>
            <table>
              <thead>
                <tr><th>Description</th><th>Qty</th><th>Unit Price</th><th>Total</th></tr>
              </thead>
              <tbody>
                {invoice.extracted.line_items.map((li, i) => (
                  <tr key={i}>
                    <td>{li.description}</td>
                    <td>{li.quantity}</td>
                    <td>{li.unit_price}</td>
                    <td>{li.total}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        <div className="modal-footer">
          <button className="btn-cancel" onClick={onClose}>Cancel</button>
          <button className="btn-save" onClick={save}>✔ Save &amp; Mark Reviewed</button>
        </div>
      </div>
    </div>
  );
}
