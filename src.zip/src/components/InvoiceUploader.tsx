import React, { useRef, useState } from 'react';

interface Props {
  onUpload: (files: File[]) => void;
  loading: boolean;
}

const ACCEPTED = '.pdf,.png,.jpg,.jpeg,.txt';

export default function InvoiceUploader({ onUpload, loading }: Props) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);

  const handle = (files: FileList | null) => {
    if (!files || files.length === 0) return;
    onUpload(Array.from(files));
  };

  return (
    <div
      className={`uploader ${dragging ? 'dragging' : ''}`}
      onClick={() => inputRef.current?.click()}
      onDragOver={e => { e.preventDefault(); setDragging(true); }}
      onDragLeave={() => setDragging(false)}
      onDrop={e => { e.preventDefault(); setDragging(false); handle(e.dataTransfer.files); }}
    >
      <input
        ref={inputRef}
        type="file"
        multiple
        accept={ACCEPTED}
        style={{ display: 'none' }}
        onChange={e => handle(e.target.files)}
      />
      {loading ? (
        <><span className="spinner-lg" /><p>Processing invoices…</p></>
      ) : (
        <>
          <div className="upload-icon">📄</div>
          <p><strong>Drop invoices here</strong> or click to browse</p>
          <p className="upload-hint">Supports PDF, PNG, JPG, TXT — batch upload supported</p>
        </>
      )}
    </div>
  );
}
