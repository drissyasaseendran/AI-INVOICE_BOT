import os, json, uuid, io, re
from datetime import datetime, timedelta
import random
import warnings
import pdfplumber
import pytesseract
from PIL import Image
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
import httpx
from dotenv import load_dotenv

warnings.filterwarnings("ignore", message="Unverified HTTPS request")
load_dotenv()

API_KEY    = os.getenv("API_KEY", "")
MODEL_URL  = os.getenv("MODEL_URL", "https://genailab.tcs.in").rstrip("/")
MODEL_NAME = os.getenv("MODEL_NAME", "gpt-4o")

app = FastAPI(title="Invoice Intelligence")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_methods=["*"],
    allow_headers=["*"],
)

store: dict = {}

# ── Prompts ────────────────────────────────────────────────────────────────

EXTRACT_PROMPT = """You are a finance-grade invoice data extraction assistant for an ERP system.
Extract ALL fields from the invoice text and return ONLY valid JSON with no markdown or explanation.

Return this exact structure:
{
  "vendor_name": "",
  "vendor_address": "",
  "vendor_email": "",
  "invoice_number": "",
  "po_number": "",
  "invoice_date": "",
  "due_date": "",
  "payment_terms": "",
  "currency": "",
  "subtotal": "",
  "tax": "",
  "tax_rate": "",
  "discount": "",
  "amount": "",
  "line_items": [
    {"description": "", "quantity": "", "unit_price": "", "total": ""}
  ],
  "validation_issues": [],
  "erp_ready": false
}

Validation rules — populate validation_issues with any of these found:
- Missing vendor_name, invoice_number, invoice_date, amount → "Missing required field: <field>"
- due_date before invoice_date → "Due date is before invoice date"
- Line item totals do not sum to subtotal (allow 0.01 tolerance) → "Line item sum mismatch"
- amount != subtotal + tax - discount (allow 0.01 tolerance) → "Total amount mismatch"
- invoice_date in the future → "Invoice date is in the future"
- Set erp_ready to true only if vendor_name, invoice_number, invoice_date, due_date, amount, currency are all present and validation_issues is empty.

Use null for any field not found. amount and subtotal must be numeric strings with 2 decimal places.

Invoice text:
"""


# ── Helpers ────────────────────────────────────────────────────────────────

def extract_text_from_file(content: bytes, filename: str) -> str:
    ext = filename.lower().rsplit(".", 1)[-1]
    if ext == "pdf":
        with pdfplumber.open(io.BytesIO(content)) as pdf:
            return "\n".join(page.extract_text() or "" for page in pdf.pages)
    elif ext in ("png", "jpg", "jpeg", "tiff", "bmp"):
        img = Image.open(io.BytesIO(content))
        return pytesseract.image_to_string(img)
    elif ext == "txt":
        return content.decode("utf-8", errors="ignore")
    raise ValueError(f"Unsupported file type: {ext}")


async def call_llm(prompt: str, temperature: float = 0, max_tokens: int = 1500) -> str:
    payload = {
        "model": MODEL_NAME,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": temperature,
        "max_tokens": max_tokens,
    }
    headers = {"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"}
    async with httpx.AsyncClient(timeout=90.0, verify=False) as client:
        res = await client.post(f"{MODEL_URL}/v1/chat/completions", json=payload, headers=headers)
        res.raise_for_status()
    return res.json()["choices"][0]["message"]["content"].strip()


def parse_json_response(raw: str) -> dict:
    if raw.startswith("```"):
        parts = raw.split("```")
        raw = parts[1] if len(parts) > 1 else raw
        if raw.startswith("json"):
            raw = raw[4:]
    return json.loads(raw.strip())


def check_duplicate(new_record: dict) -> Optional[str]:
    inv_no = new_record.get("extracted", {}).get("invoice_number")
    vendor  = new_record.get("extracted", {}).get("vendor_name")
    if not inv_no:
        return None
    for rid, rec in store.items():
        if rid == new_record.get("id"):
            continue
        if (rec.get("extracted", {}).get("invoice_number") == inv_no and
                rec.get("extracted", {}).get("vendor_name") == vendor):
            return f"Duplicate invoice: {inv_no} from {vendor} already exists (id: {rid[:8]})"
    return None


# ── Models ─────────────────────────────────────────────────────────────────

class InvoiceUpdate(BaseModel):
    vendor_name: Optional[str] = None
    vendor_address: Optional[str] = None
    vendor_email: Optional[str] = None
    invoice_number: Optional[str] = None
    po_number: Optional[str] = None
    invoice_date: Optional[str] = None
    due_date: Optional[str] = None
    payment_terms: Optional[str] = None
    currency: Optional[str] = None
    subtotal: Optional[str] = None
    tax: Optional[str] = None
    tax_rate: Optional[str] = None
    discount: Optional[str] = None
    amount: Optional[str] = None


class ChatRequest(BaseModel):
    message: str
    history: list[dict] = []


# ── Routes ─────────────────────────────────────────────────────────────────

@app.get("/")
def health():
    return {"status": "ok", "model": MODEL_NAME}


@app.post("/invoice/upload")
async def upload_invoices(files: list[UploadFile] = File(...)):
    results = []
    for file in files:
        invoice_id = str(uuid.uuid4())
        record = {
            "id": invoice_id,
            "filename": file.filename,
            "status": "processing",
            "extracted": {},
            "validation_issues": [],
            "erp_ready": False,
            "error": None,
            "uploaded_at": datetime.utcnow().isoformat(),
        }
        store[invoice_id] = record
        try:
            content = await file.read()
            text = extract_text_from_file(content, file.filename)
            raw = await call_llm(EXTRACT_PROMPT + text)
            extracted = parse_json_response(raw)
            record["extracted"] = {k: v for k, v in extracted.items()
                                   if k not in ("validation_issues", "erp_ready")}
            record["validation_issues"] = extracted.get("validation_issues", [])
            record["erp_ready"] = extracted.get("erp_ready", False)
            # Duplicate check
            dup = check_duplicate(record)
            if dup and dup not in record["validation_issues"]:
                record["validation_issues"].append(dup)
                record["erp_ready"] = False
            record["status"] = "done"
        except Exception as e:
            record["status"] = "error"
            record["error"] = str(e)
        results.append(record)
    return results


@app.get("/invoice/{invoice_id}")
def get_invoice(invoice_id: str):
    if invoice_id not in store:
        raise HTTPException(status_code=404, detail="Invoice not found")
    return store[invoice_id]


@app.patch("/invoice/{invoice_id}")
def update_invoice(invoice_id: str, update: InvoiceUpdate):
    if invoice_id not in store:
        raise HTTPException(status_code=404, detail="Invoice not found")
    record = store[invoice_id]
    patch = {k: v for k, v in update.model_dump().items() if v is not None}
    record["extracted"].update(patch)
    record["validation_issues"] = []
    record["erp_ready"] = True
    record["status"] = "reviewed"
    return record


@app.get("/invoices")
def list_invoices():
    return list(store.values())


@app.delete("/invoices")
def clear_invoices():
    store.clear()
    return {"status": "cleared"}


@app.get("/analytics")
def analytics():
    all_inv = list(store.values())
    total = len(all_inv)
    if total == 0:
        return {"total": 0, "extracted": 0, "reviewed": 0, "erp_ready": 0,
                "with_issues": 0, "errors": 0, "total_spend": 0,
                "by_vendor": [], "by_status": [], "issue_types": []}

    extracted  = sum(1 for i in all_inv if i["status"] in ("done", "reviewed"))
    reviewed   = sum(1 for i in all_inv if i["status"] == "reviewed")
    erp_ready  = sum(1 for i in all_inv if i.get("erp_ready"))
    with_issues = sum(1 for i in all_inv if i["validation_issues"])
    errors     = sum(1 for i in all_inv if i["status"] == "error")

    total_spend = 0.0
    vendor_spend: dict = {}
    issue_counter: dict = {}

    for inv in all_inv:
        amt = inv.get("extracted", {}).get("amount")
        vendor = inv.get("extracted", {}).get("vendor_name") or "Unknown"
        try:
            val = float(amt or 0)
            total_spend += val
            vendor_spend[vendor] = vendor_spend.get(vendor, 0) + val
        except Exception:
            pass
        for issue in inv.get("validation_issues", []):
            # Bucket issue type
            key = re.sub(r":.*", "", issue).strip()
            issue_counter[key] = issue_counter.get(key, 0) + 1

    by_vendor = sorted(
        [{"vendor": k, "amount": round(v, 2)} for k, v in vendor_spend.items()],
        key=lambda x: x["amount"], reverse=True
    )[:10]

    by_status = [
        {"status": "Extracted", "count": extracted - reviewed},
        {"status": "Reviewed",  "count": reviewed},
        {"status": "Issues",    "count": with_issues},
        {"status": "Error",     "count": errors},
    ]

    issue_types = [{"type": k, "count": v} for k, v in issue_counter.items()]

    return {
        "total": total, "extracted": extracted, "reviewed": reviewed,
        "erp_ready": erp_ready, "with_issues": with_issues, "errors": errors,
        "total_spend": round(total_spend, 2),
        "by_vendor": by_vendor, "by_status": by_status, "issue_types": issue_types,
    }


@app.post("/invoice/generate-samples")
async def generate_samples():
    """Generate 20 synthetic invoices for demo purposes."""
    vendors = [
        ("Acme Supplies Ltd",      "123 Industrial Ave, Chicago IL",  "billing@acme.com"),
        ("TechParts Inc",          "456 Silicon Blvd, Austin TX",     "ap@techparts.com"),
        ("Global Logistics Co",    "789 Harbor Rd, Los Angeles CA",   "invoices@globallog.com"),
        ("Office Essentials",      "321 Commerce St, New York NY",    "finance@officeess.com"),
        ("CloudServ Solutions",    "555 Data Center Dr, Seattle WA",  "billing@cloudserv.com"),
        ("BuildRight Materials",   "88 Construction Way, Denver CO",  "ar@buildright.com"),
        ("MediSupply Corp",        "200 Health Pkwy, Boston MA",      "billing@medisupply.com"),
        ("FastFreight LLC",        "900 Logistics Loop, Dallas TX",   "invoices@fastfreight.com"),
        ("GreenEnergy Partners",   "77 Solar St, Phoenix AZ",         "ap@greenenergy.com"),
        ("DataSafe Security",      "44 Cyber Ave, San Jose CA",       "billing@datasafe.com"),
    ]
    terms_options = ["Net 30", "Net 45", "Net 60", "Due on Receipt"]
    currencies    = ["USD", "USD", "USD", "EUR", "GBP"]

    generated = []
    base_date = datetime(2024, 1, 1)

    for i in range(20):
        vendor = vendors[i % len(vendors)]
        inv_date = base_date + timedelta(days=i * 12)
        terms = terms_options[i % len(terms_options)]
        days_due = {"Net 30": 30, "Net 45": 45, "Net 60": 60, "Due on Receipt": 0}[terms]
        due_date = inv_date + timedelta(days=days_due)
        currency = currencies[i % len(currencies)]

        # Generate 1-4 line items
        items = []
        subtotal = 0.0
        for j in range(random.randint(1, 4)):
            qty   = random.randint(1, 20)
            price = round(random.uniform(50, 2000), 2)
            total = round(qty * price, 2)
            subtotal += total
            items.append({"description": f"Service/Product Item {j+1}", "quantity": str(qty),
                          "unit_price": str(price), "total": str(total)})

        subtotal = round(subtotal, 2)
        tax_rate = random.choice([0.05, 0.08, 0.10, 0.18])
        tax      = round(subtotal * tax_rate, 2)
        discount = round(subtotal * random.choice([0, 0, 0, 0.02, 0.05]), 2)
        amount   = round(subtotal + tax - discount, 2)

        # Intentionally introduce issues in some invoices for demo
        issues = []
        erp_ready = True
        if i == 3:   # missing due date
            due_date_str = None
            issues.append("Missing required field: due_date")
            erp_ready = False
        else:
            due_date_str = due_date.strftime("%Y-%m-%d")

        if i == 7:   # amount mismatch
            amount = round(amount + 50, 2)
            issues.append("Total amount mismatch")
            erp_ready = False

        if i == 11:  # future invoice date
            inv_date = datetime.utcnow() + timedelta(days=10)
            issues.append("Invoice date is in the future")
            erp_ready = False

        if i == 15:  # missing vendor email
            vendor = (vendor[0], vendor[1], None)

        invoice_id = str(uuid.uuid4())
        record = {
            "id": invoice_id,
            "filename": f"invoice_{i+1:02d}_{vendor[0].replace(' ', '_')}.txt",
            "status": "done",
            "erp_ready": erp_ready,
            "validation_issues": issues,
            "error": None,
            "uploaded_at": datetime.utcnow().isoformat(),
            "extracted": {
                "vendor_name":    vendor[0],
                "vendor_address": vendor[1],
                "vendor_email":   vendor[2],
                "invoice_number": f"INV-2024-{1000 + i}",
                "po_number":      f"PO-{5000 + i}" if i % 3 != 0 else None,
                "invoice_date":   inv_date.strftime("%Y-%m-%d"),
                "due_date":       due_date_str,
                "payment_terms":  terms,
                "currency":       currency,
                "subtotal":       str(subtotal),
                "tax":            str(tax),
                "tax_rate":       f"{int(tax_rate * 100)}%",
                "discount":       str(discount) if discount > 0 else None,
                "amount":         str(amount),
                "line_items":     items,
            },
        }
        store[invoice_id] = record
        generated.append(record)

    return generated


@app.post("/chat")
async def chat(req: ChatRequest):
    if not store:
        return {"type": "text", "content": "No invoices loaded yet. Upload invoices or generate sample data first."}

    invoice_context = json.dumps(
        [{"id": r["id"][:8], "filename": r["filename"], "status": r["status"],
          "erp_ready": r.get("erp_ready"), **r.get("extracted", {}),
          "validation_issues": ", ".join(r["validation_issues"]) or "None"}
         for r in store.values()],
        indent=2,
    )

    system_prompt = (
        "You are an expert finance assistant for a back-office invoice processing system.\n"
        "You have access to extracted invoice data below.\n\n"
        "RESPONSE FORMAT RULES — strictly follow these:\n"
        "1. When the user asks to LIST, SHOW, or GET multiple invoices (e.g. 'show all invoices', "
        "'list invoices with issues', 'show ERP ready invoices', 'show all'), respond with ONLY this JSON:\n"
        '   {"type": "table", "columns": ["Invoice ID", "Vendor", "Invoice #", "Date", "Amount", "Status", "ERP Ready", "Issues"], '
        '"rows": [["id","vendor","inv#","date","amount","status","erp","issues"], ...]}\n'
        "2. When the user asks a single-record lookup (e.g. 'show invoice INV-001'), respond with ONLY this JSON:\n"
        '   {"type": "table", "columns": ["Field", "Value"], "rows": [["field","value"], ...]}\n'
        "3. For all other questions (totals, counts, summaries, explanations), respond with ONLY this JSON:\n"
        '   {"type": "text", "content": "your answer here"}\n'
        "Do NOT include any text outside the JSON. Do NOT use markdown.\n\n"
        f"INVOICE DATA:\n{invoice_context}"
    )

    messages = [{"role": "system", "content": system_prompt}]
    messages += req.history[-10:]
    messages.append({"role": "user", "content": req.message})

    payload = {
        "model": MODEL_NAME,
        "messages": messages,
        "temperature": 0.1,
        "max_tokens": 2048,
    }
    headers = {"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"}

    try:
        async with httpx.AsyncClient(timeout=60.0, verify=False) as client:
            res = await client.post(f"{MODEL_URL}/v1/chat/completions", json=payload, headers=headers)
            res.raise_for_status()
        raw = res.json()["choices"][0]["message"]["content"].strip()
        # Strip markdown fences if model wraps in ```json
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
            raw = raw.strip()
        try:
            parsed = json.loads(raw)
            return parsed  # already {type, columns, rows} or {type, content}
        except Exception:
            return {"type": "text", "content": raw}
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=f"LLM error: {e.response.text}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
